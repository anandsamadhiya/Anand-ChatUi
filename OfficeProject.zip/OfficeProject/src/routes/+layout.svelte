<script>
  import "../app.css";
  // import Sidebar from "../lib/components/Sidebar.svelte";
</script>

<!-- <div class="flex">
  <div class="w-56 md:block hidden">
    <Sidebar />
  </div> -->

<slot />
<!-- </div> -->
